#!/bin/bash
cmd="gcc -Wall -std=c11 uppercase.c -o uppercase"
executable="uppercase"
