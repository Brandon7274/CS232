#!/bin/bash
expected="arith.c"
