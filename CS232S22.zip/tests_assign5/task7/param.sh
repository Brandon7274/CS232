#!/bin/bash
expected="snode.c slist.c Makefile snode.h slist.h snode_test.c song_list.c"
