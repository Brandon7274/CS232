#!/bin/bash
expected="set_bits.c test_set_bits.c"
