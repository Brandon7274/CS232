#!/bin/bash
cmd="gcc -Wall -std=c11 flip_bits.c test_flip_bits.c -o test_flip_bits"
executable="test_flip_bits"
